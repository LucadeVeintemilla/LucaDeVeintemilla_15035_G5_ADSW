import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { AuthContext } from "../context/authContext";
import Logo from "../img/logoespereina.png";

const Navbar = (props) => {
  const { currentUser, logout } = useContext(AuthContext);
  return (
    <div>
      <div className='barraNavegacion'>
        <div className="logoContainer" id="logoNav">
          <img src={Logo} alt="Logo Espereina" />
        </div>
        <div class="titleContainer">
          <h1>{props.texto}</h1>
        </div>
        <div class="userContainer">
          {<div className='logueo'>
            <br />
            <span>{currentUser?.name + " " + currentUser?.lastname}</span>
            <br />
            {currentUser ? (
              <span onClick={logout}><i>Cerrar Sesión</i></span>
            ) : (
              <Link className="link" to="/login">
                Inicio Sesion
              </Link>
            )}
          </div>}
        </div>
      </div>
    </div>
  );
};
export default Navbar;
