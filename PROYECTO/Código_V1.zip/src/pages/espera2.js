import './espera2.css';

function Espera2() {
  return (
    <div className="espera2">
      <figure className='cortina_izquierda'>
      </figure>
      <figure className='cortina_derecha'>
      </figure>
      <h1>Traje de gala</h1>
    </div>
  );
}

export default Espera2;
